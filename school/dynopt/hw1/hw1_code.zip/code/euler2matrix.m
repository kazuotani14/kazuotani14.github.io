function [R] = euler2matrix(roll, pitch, yaw)

%      roll = 0.0; pitch = 0.0; yaw = 0.0;

    theta = roll; 
    phi = pitch;
    psi = yaw;

    Rx = [1 0 0; 
          0 cos(theta) -sin(theta); 
          0 sin(theta) cos(theta)];
    Ry = [cos(phi) 0 sin(phi); 
          0 1 0; 
          -sin(phi) 0 cos(phi)]; 
    Rz = [cos(psi) -sin(psi) 0; 
         sin(psi) cos(psi) 0; 
         0 0 1]; 
         
    R = Rz*Ry*Rx;
    
%     p = R*[0;1;0];
%     plotArm([0,p(1)],[0,p(2)],[0,p(3)]);
 
end
