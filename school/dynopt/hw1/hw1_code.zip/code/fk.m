function [X, Y, Z, R] = fk(link_length, roll, pitch, yaw)
% Input: 
% link_length: vector of link lengths, starting from base
% roll, pitch, yaw: vectors of orientations, starting with base to link 1
% Output: x,y,z vectors denoting positions of joints
% Base of robot/link 1 = position [0, 0, 0], with joint 0 being origin

n = length(link_length);

joint_pos = zeros(n+1,4);
joint_pos(1,:) = [0, 0, 0, 1];
R = eye(4); % rotation matrix so far. will get updated at each joint

for i = 1:n
    last_joint = joint_pos(i,:)';
    r=roll(i); p=pitch(i); y=yaw(i);
    l = link_length(i);
%     Rx = [1 0 0 0; 
%           0 cos(theta) -sin(theta) 0; 
%           0 sin(theta) cos(theta) 0; 
%           0 0 0 1];
%     Ry = [cos(phi) 0 sin(phi) 0; 
%           0 1 0 0; 
%           -sin(phi) 0 cos(phi) 0; 
%           0 0 0 1];
%     Rz = [cos(psi) -sin(psi) 0 0; 
%          sin(psi) cos(psi) 0 0; 
%          0 0 1 0; 
%          0 0 0 1];
%     Ri = Rx*Ry*Rz; 
    Ri = [cos(p)*cos(y), -cos(p)*sin(y), sin(p), 0;
          cos(r)*sin(y) + cos(y)*sin(p)*sin(r), cos(y)*cos(r) - sin(p)*sin(y)*sin(r), -cos(p)*sin(r), 0;
          sin(y)*sin(r) - cos(y)*cos(r)*sin(p), cos(y)*sin(r) + cos(r)*sin(p)*sin(y),  cos(p)*cos(r), 0;
          0, 0, 0, 1];

    R = Ri*R;
    next_joint = R*[l;0;0;1] + last_joint;
    next_joint(4) = 1;
    
    joint_pos(i+1, :) = next_joint;
end

X = joint_pos(:,1);
Y = joint_pos(:,2);
Z = joint_pos(:,3);
% R is rotation matrix of end effector relative to base frame 

end