function [rf, pf, yf, score_f] = part4( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
%%Outputs 
  % [r, p, y] = roll, pitch, yaw vectors of the N joint angles
  %            (N link coordinate frames)
%%Inputs:
    % target: [x, y, z, q0, q1, q2, q3]' position and orientation of the end
    %    effector
    % link_length : Nx1 vectors of the lengths of the links
    % min_xxx, max_xxx are the vectors of the 
    %    limits on the roll, pitch, yaw of each link.
    % limits for a joint could be something like [-pi, pi]
    % obstacles: A Mx4 matrix where each row is [ x y z radius ] of a sphere
    %    obstacle. M obstacles.

% Rotations about x:theta, y:phi, z:psi

global lb;
global ub;

p0 = setup_problem(target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles);

%--------------------------------------------------------------------------
% TODO run one algorithm (best or fastest from part 3) while randomly
% perturbing link 1 rpy to provide a few initial conditions. Rank local
% minima in terms of returned score 
n_ICs = 5;

n = length(p0);

scores = zeros(n_ICs,1);
answers = zeros(n_ICs,n);

for i = 1:n_ICs

    p0(1) = (rand()-0.5)*pi/2;
    p0(n/3+1) = (rand()-0.5)*pi/2;
    p0(2*n/3+1) = (rand()-0.5)*pi/2;
    
%     options = optimset('Display','iter','MaxFunEvals',1000000,'Algorithm','sqp');
%     [answer,fval,exitflag]=fmincon(@criterion,p0, [], [], [], [], lb, ub, @constraint, options);

    n_joints = length(link_length)+1;
    sigma0 = ones(n_joints*3,1)*0.2;
    opts = cmaes;
    opts.MaxIter = 500;
    [xmin, fmin, counteval, stopflag, out, bestever] = cmaes('criterion_cmaes', p0, sigma0, opts);
    answer = xmin; fval = fmin; exitflag=1;

    scores(i) = fval;
    answers(i,:) = answer;
    
    show_sol(answer, fval, exitflag);
    pause
end

% To find best solution, look for lowest score out of all attempts
[m,i] = min(scores);
best = answers(i,:);

%  To find the second best answer, just find the next best score
scores(i) = 9999;
[m,i] = min(scores);
second = answers(i,:);


end