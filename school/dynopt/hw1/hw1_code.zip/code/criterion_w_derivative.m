function [score, derivative] = criterion_w_derivative(p)
%%% optimization criterion: p is vector of joint angles
% [roll; pitch; yaw]

global lengths;
global x_d;
global ub lb R_d obs;

FINITE_DIF = 1;

% Find derivative with finite differences
if (FINITE_DIF)
    score = criterion(p);
    eps = 1e-5;
    derivative = zeros(length(p),1);
    for i = 1:length(p)
        p2 = p;
        p2(i) = p2(i)+eps;
        score2 = criterion(p2);
        derivative(i) = (score2-score);
    end
    
% Using Jacobians
else
    n = length(p);

    p = reshape(p,1,length(p));

    roll = p(1:n/3);
    pitch = p(n/3+1:2*n/3);
    yaw = p(2*n/3+1:n);

    [X,Y,Z,R_all] = fk_diff(lengths, roll, pitch, yaw); 

    Rend = R_all(:,:,end);
    
    % Position cost
    c_pos = 10;
    x = [X(end); Y(end); Z(end)];
    pos_cost = c_pos*(x - x_d)'*(x-x_d);

    % Joint limit cost
    c_lim = 0.0001;
    if (~isempty(lb) && ~isempty(ub)) 
        mid = ub-lb;
        diff = p'-mid';
        lim_cost = c_lim*(diff)'*(diff);
    else
        lim_cost = 0;
    end

    % End effector orientation cost
    c_R = 5;
    dR = R_d*Rend(1:3,1:3)';
    [ro,pi,ya] = matrix2euler(dR);
    rpy_diff = [ro,pi,ya]';
    rot_cost = c_R * (rpy_diff'*rpy_diff);

    % Obstacle cost
    c_obs = 100;    
    cushion = 0.1;  % Distance that we want arm to stay away from obstacles

    if (~isempty(obs))
       % Check distance from each line segment to each obstacle
        intersections = 0;
        for link = 1:length(lengths)
           for i = 1:size(obs,1)
               p1 = [X(link), Y(link), Z(link)];
               p2 = [X(link+1), Y(link+1), Z(link+1)];
               p3 = obs(i,1:3);
               r = obs(i,4);
               dist = point_line_dist(p1,p2,p3);
               if(dist<(r+cushion))
                   intersections = intersections + (r+cushion-dist);
               end
           end
        end
        obs_cost = c_obs * intersections;
    else
       obs_cost = 0;
    end

    score = pos_cost + lim_cost + rot_cost + obs_cost;
         
    x = [X(end), Y(end), Z(end)]';
    dcost = 2*(x-x_d);              % positive gradient -> + cost when moving in + direction for that axis
    derivative = zeros(length(p),1);
                   
    for i = 1:length(X)
        
        R_current = Rend(1:3,1:3)'*R_all(1:3,1:3,i);    %R joint i-end
        [theta, phi, psi] = matrix2euler(R_current);
                        
        Ji =  [   0,            -cos(psi)*sin(phi),                                 -cos(phi)*sin(psi);
               cos(psi)*cos(theta)*sin(phi) - sin(psi)*sin(theta),  cos(phi)*cos(psi)*sin(theta), cos(psi)*cos(theta) - sin(phi)*sin(psi)*sin(theta);
               cos(theta)*sin(psi) + cos(psi)*sin(phi)*sin(theta), -cos(phi)*cos(psi)*cos(theta), cos(psi)*sin(theta) + cos(theta)*sin(phi)*sin(psi)];
        
        mat = Ji'*dcost;        % Jacobians are column major!
        derivative(3*(i-1)+1) = mat(1);
        derivative(3*(i-1)+2) = mat(2);
        derivative(3*(i-1)+3) = mat(3);
    end
           
end %end if (FINITE_DIF)


% plotArm(X,Y,Z)
% derivative'

end
