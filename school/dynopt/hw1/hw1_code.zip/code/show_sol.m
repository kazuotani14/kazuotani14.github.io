function show_sol(answer, fval, exitflag)

global x_d;
global lengths;

% Show answer
n = length(answer);
roll = answer(1:n/3); pitch = answer(n/3+1:2*n/3); yaw = answer(2*n/3+1:n);
[X,Y,Z] = fk(lengths, roll, pitch, yaw);
xf = X(end,1);
yf = Y(end,1);
zf = Z(end,1);

fprintf('Goal end effector point was: %f %f %f\n', x_d(1), x_d(2), x_d(3));
fprintf('Final end effector point was: %f %f %f\n', xf, yf, zf);
fprintf('Final cost function value: %f\n', fval);
if (exitflag<0)
    fprintf('Something went wrong during the optimization.\n');
end
  
plotArm(X,Y,Z)
  
end