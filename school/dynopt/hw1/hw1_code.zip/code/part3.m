function [rf, pf, yf, score_f] = part3( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
%%Outputs 
  % [r, p, y] = roll, pitch, yaw vectors of the N joint angles
  %            (N link coordinate frames)
%%Inputs:
    % target: [x, y, z, q0, q1, q2, q3]' position and orientation of the end
    %    effector
    % link_length : Nx1 vectors of the lengths of the links
    % min_xxx, max_xxx are the vectors of the 
    %    limits on the roll, pitch, yaw of each link.
    % limits for a joint could be something like [-pi, pi]
    % obstacles: A Mx4 matrix where each row is [ x y z radius ] of a sphere
    %    obstacle. M obstacles.

% Rotations about x:theta, y:phi, z:psi

global lb;
global ub;

p0 = setup_problem(target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles);

%--------------------------------------------------------------------------
% Algorithms
% 1 - CMA-ES
% 2 - SQP
% 3 - Interior point (default)
% 4 - Active set
% 5 - Trust region reflective w/derivative
algorithm = 1;

switch algorithm
    case 1 % CMA-ES, capped at 500 iterations
        n_joints = length(link_length)+1;
        sigma0 = ones(n_joints*3,1)*0.2;
        opts = cmaes;
        opts.MaxIter = 500;
        [xmin, fmin, counteval, stopflag, out, bestever] = cmaes('criterion_cmaes', p0, sigma0, opts);
        answer = xmin; fval = fmin; exitflag=1;
    case 2  % SQP
        options = optimset('Display','iter','MaxFunEvals',1000000,'Algorithm','sqp');
        [answer,fval,exitflag]=fmincon(@criterion,p0, [], [], [], [], lb, ub, @constraint, options);
    case 3  % Interior point
        options = optimset('Display','iter','MaxFunEvals',1000000,'Algorithm','interior-point');
        [answer,fval,exitflag]=fmincon(@criterion,p0, [], [], [], [], lb, ub, @constraint, options);
    case 4  % Active set
        options = optimset('Display','iter','MaxFunEvals',1000000,'Algorithm','active-set');
        [answer,fval,exitflag]=fmincon(@criterion,p0, [], [], [], [], lb, ub, @constraint, options);
end

%--------------------------------------------------------------------------

show_sol(answer, fval, exitflag);


end