function plotArm(X, Y, Z)
% Uses plot3 to show arm

global x_d;
global obs;

axis_l = 2; % TODO: Make this max dimension in joint positions 
plot3([axis_l,0],[0,0],[0,0], 'Color', 'g','LineWidth',1.5) % plot x-axis
grid on; hold on; axis equal;
plot3([0,0],[axis_l,0],[0,0], 'Color', 'b','LineWidth',1.5) % plot y-axis
plot3([0,0],[0,0],[axis_l,0], 'Color', 'r','LineWidth',1.5) % plot z-axis
xlabel('x')
ylabel('y')
zlabel('z')
plot3(x_d(1),x_d(2),x_d(3),'.','MarkerSize',30,'Color','g')

for i = 1:length(X)-1
    p1 = [X(i), Y(i), Z(i)];
    p2 = [X(i+1), Y(i+1), Z(i+1)];
    plot3([p1(1),p2(1)],[p1(2),p2(2)],[p1(3),p2(3)],'Color','k','LineWidth',5)
    plot3(p1(1),p1(2),p1(3),'.','MarkerSize',30,'Color','m')
    plot3(p2(1),p2(2),p2(3),'.','MarkerSize',30,'Color','m')
end

% Draw obstacles
for i = 1:size(obs,1)
    center = obs(i,1:3);
    r = obs(i,4);
    [x,y,z] = sphere(50);
    x = x*r + center(1);
    y = y*r + center(2);
    z = z*r + center(3);
    surface(x,y,z, 'FaceColor', 'none', 'EdgeColor','r'); 
end

drawnow
 
hold off

end