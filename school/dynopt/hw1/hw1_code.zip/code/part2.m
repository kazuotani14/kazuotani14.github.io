function [r, p, y] = part2( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
%% Function that uses analytic gradients to do optimization for inverse kinematics in a snake robot

%%Outputs 
  % [r, p, y] = roll, pitch, yaw vectors of the N joint angles
  %            (N link coordinate frames)
%%Inputs:
    % target: [x, y, z, q0, q1, q2, q3]' position and orientation of the end
    %    effector
    % link_length : Nx1 vectors of the lengths of the links
    % min_xxx, max_xxx are the vectors of the 
    %    limits on the roll, pitch, yaw of each link.
    % limits for a joint could be something like [-pi, pi]
    % obstacles: A Mx4 matrix where each row is [ x y z radius ] of a sphere
    %    obstacle. M obstacles.

% TODO: 
% Add constraint for obstacles
% more test cases
% b. add gradient information to criterion and constraint functions
% c. Try different algorithms

global lb;
global ub;

p0 = setup_problem(target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles);

%--------------------------------------------------------------------------
% Optimization with derivative information
% options = optimoptions('fmincon','SpecifyObjectiveGradient',true,'Display','iter','Algorithm','active-set','StepTolerance',0,'MaxFunEvals',1000000);
options = optimoptions('fmincon','SpecifyObjectiveGradient',true,'Display','iter','Algorithm','interior-point','MaxFunEvals',1000000);
% options = optimoptions('fmincon','SpecifyObjectiveGradient',true,'Display','iter','Algorithm','sqp','MaxFunEvals',1000000);

% [answer,fval,exitflag]=fmincon(@criterion_w_derivative,p0, [], [], [], [], [], [], @constraint_trustregion, options);
[answer,fval,exitflag]=fmincon(@criterion_w_derivative, p0, [], [], [], [], lb, ub, @constraint, options);


%--------------------------------------------------------------------------

show_sol(answer, fval, exitflag);
end