% Find a systematic way to compute the derivative of the tip position and 
% orientation with respect to each set of joint angles for the 3D case. 
% Note that the robot is recursive. If you can compute this for one 
% joint/link, you can compute it for all of them.

syms th ph ps

% th = 0; ph = 0; ps = pi/4;

Rx = [1 0 0; 
      0 cos(th) -sin(th); 
      0 sin(th) cos(th)];
Ry = [cos(ph) 0 sin(ph); 
      0 1 0; 
      -sin(ph) 0 cos(ph)]; 
Rz = [cos(ps) -sin(ps) 0; 
     sin(ps) cos(ps) 0; 
     0 0 1]; 
 
R = Rx*Ry*Rz;

% R1 = subs(R,[th ph ps],[sym('t1') sym('ph1') sym('ps1')]);

syms x1 x2 x3;

vars = [th , ph, ps];

v = [1; 0; 0];
v2 = R*v;

Jx = jacobian(v2,vars); % Jacobian of v2 wrt roll, pitch, yaw of previous joint

Jx = subs(Jx,[th ph ps],[0 0 0]);
