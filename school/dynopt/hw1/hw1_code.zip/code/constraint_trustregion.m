function [c, c_eq] = constraint_trustregion(p)
% optimizer will make sure c<=0
global lb ub obs lengths;

n = length(p);

roll = p(1:n/3);
pitch = p(n/3+1:2*n/3);
yaw = p(2*n/3+1:n);

[X,Y,Z,R] = fk(lengths, roll, pitch, yaw); 

% Obstacle constraint
if (~isempty(obs))
   % Check distance from each line segment to closest obstacle
   intersections = 0;
   
   for link = 1:length(lengths)
       for i = 1:size(obs,1)
           p1 = [X(link), Y(link), Z(link)];
           p2 = [X(link+1), Y(link+1), Z(link+1)];
           p3 = obs(i,1:3);
           r = obs(i,4);
           dist = point_line_dist(p1,p2,p3);
           if(dist<r)
               intersections = intersections + (r-dist);
           end
       end
   end
   c_eq = intersections;
else
    c_eq = [];
end

lb_hit = p<lb;
ub_hit = p>ub;

c_eq = c_eq + sum(lb_hit) + sum(ub_hit);

c = [];

end