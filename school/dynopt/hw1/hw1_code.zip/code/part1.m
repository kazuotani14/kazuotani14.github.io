function [rf, pf, yf, score_f] = part1( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
%% Function that uses optimization to do inverse kinematics for a snake robot

%%Outputs 
  % [r, p, y] = roll, pitch, yaw vectors of the N joint angles
  %            (N link coordinate frames)
%%Inputs:
    % target: [x, y, z, q0, q1, q2, q3]' position and orientation of the end
    %    effector
    % link_length : Nx1 vectors of the lengths of the links
    % min_xxx, max_xxx are the vectors of the 
    %    limits on the roll, pitch, yaw of each link.
    % limits for a joint could be something like [-pi, pi]
    % obstacles: A Mx4 matrix where each row is [ x y z radius ] of a sphere
    %    obstacle. M obstacles.

% Rotations about x:theta, y:phi, z:psi

global lb;
global ub;

p0 = setup_problem(target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles);

%--------------------------------------------------------------------------
 options = optimset('Display','iter','MaxFunEvals',1000000,'Algorithm','active-set');

[answer,fval,exitflag]=fmincon(@criterion,p0, [], [], [], [], lb, ub, @constraint, options);

%--------------------------------------------------------------------------
show_sol(answer, fval, exitflag);

end