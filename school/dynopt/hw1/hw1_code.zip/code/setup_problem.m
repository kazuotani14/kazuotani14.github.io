function [p0] = setup_problem( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles)

% Make sure all inputs are in the shape they're supposed to be in
target = reshape(target, 7,1);
min_roll = reshape(min_roll, 1, length(min_roll));
max_roll = reshape(max_roll, 1, length(max_roll));
min_pitch = reshape(min_pitch, 1, length(min_pitch));
max_pitch = reshape(max_pitch, 1, length(max_pitch));
min_yaw = reshape(min_yaw, 1, length(min_yaw));
max_yaw = reshape(max_yaw, 1, length(max_yaw));

global lengths;
lengths = link_length;

global x_d;
x_d = target(1:3);

global R_d;
if (length(target)==7)
    q_d = target(4:7);
    R_d = quat2matrix(q_d);
else
    R_d = eye(3);
end

global obs;
obs = obstacles;

n_joints = length(link_length)+1;

global lb;
global ub;
lb = [min_roll, min_pitch, min_yaw];
ub = [max_roll, max_pitch, max_yaw];


if(norm(x_d)>sum(link_length))
    disp('Goal point is out of manipulator range. Will find close point.');
end

p0 = zeros(1,n_joints*3);   % Initial guess is all zeros at joints
% p0 = rand([1,n_joints*3]);

end