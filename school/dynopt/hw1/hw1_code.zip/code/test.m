% Test IK in part 1

clc; clear all; close all;

n_links = 10;
link_lengths = ones(n_links,1) * 0.5;

lb = ones(1,n_links+1)*-pi/2;
ub = ones(1,n_links+1)*pi/2;

M = [1 0 0.5 0.3;
     1 1 1 0.3;
     0 1 0.7 0.5;
     2 1 1 0.5];

% target = rand([3,1])*3;
target = [2,0,2]';
% target = [1 -0.5 0]';

% q = eul2quat([0,0,0])';
q = eul2quat([pi/4, 0, 0])';
% q = eul2quat([0, -pi, 0])';

target = [target; q];
disp(target');

tic

part1(target,link_lengths, lb, ub, lb, ub, lb, ub, M)
% part2(target,link_lengths, lb, ub, lb, ub, lb, ub, M)
% part3(target,link_lengths, lb, ub, lb, ub, lb, ub, M)
% part4(target,link_lengths, lb, ub, lb, ub, lb, ub, M)

% elapsedTime = toc
toc
