function score = criterion_cmaes(p)
%%% optimization criterion: p is vector of joint angles
% [roll; pitch; yaw]

global x_d;
global R_d;
global lengths;
global lb;
global ub;
global obs;

n = length(p);

p = reshape(p,1,length(p));

roll = p(1:n/3);
pitch = p(n/3+1:2*n/3);
yaw = p(2*n/3+1:n);

[X,Y,Z,R] = fk(lengths, roll, pitch, yaw); 

% Position cost
c_pos = 10;
x = [X(end); Y(end); Z(end)];
pos_cost = c_pos*(x - x_d)'*(x-x_d);

% Joint limit cost
c_lim = 0.0001;
if (~isempty(lb) && ~isempty(ub)) 
    mid = ub-lb;
    diff = p'-mid';
    lim_cost = c_lim*(diff)'*(diff);
else
    lim_cost = 0;
end

% End effector orientation cost
c_R = 5;
dR = R_d*R(1:3,1:3)';
[r,p,y] = matrix2euler(dR);
% x = rotm2eul(dR);
% r = x(1); p = x(2); y = x(3);
rpy_diff = [r,p,y]';
rot_cost = c_R * (rpy_diff'*rpy_diff);

% Obstacle cost
c_obs = 100;    
cushion = 0.1;  % Distance that we want arm to stay away from obstacles

if (~isempty(obs))
   % Check distance from each line segment to each obstacle
    intersections = 0;
    for link = 1:length(lengths)
       for p = 1:size(obs,1)
           p1 = [X(link), Y(link), Z(link)];
           p2 = [X(link+1), Y(link+1), Z(link+1)];
           p3 = obs(p,1:3);
           r = obs(p,4);
           dist = point_line_dist(p1,p2,p3);
           if(dist<(r+cushion))
               intersections = intersections + (r+cushion-dist);
           end
       end
    end
    obs_cost = c_obs * intersections;
else
   obs_cost = 0;
end

score = pos_cost + lim_cost + rot_cost + obs_cost;

% fprintf('pos_cost, lim_cost, rot_cost, obs_cost\n');
% fprintf('%f %f %f %f\n', pos_cost, lim_cost, rot_cost, obs_cost);

end
