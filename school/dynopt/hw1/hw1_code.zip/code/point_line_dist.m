function [dist] = point_line_dist(p1, p2, p3)
% p1 and p2 define line segment, p3 is center of obstacle

dp = p2-p1;
v  = p3-p1;

c = dot(v, dp)/norm(dp); % project point onto vector

% If projection is positive, closest point on line is somewhere in middle
% Else, closest point is one of the endpoints
if c>=0 && c<norm(dp)
    p_closest = p1 + dp/norm(dp)*c;
    dist = norm(p3-p_closest);
else
    dist = min(norm(p3-p1), norm(p3-p2));
end

end
