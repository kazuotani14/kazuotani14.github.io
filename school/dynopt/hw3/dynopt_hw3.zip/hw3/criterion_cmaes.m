function score = criterion_cmaes(foot_forces)
%%% optimization criterion
% I think this is just the same thing but vectorized in transpose

score = 0;

end
