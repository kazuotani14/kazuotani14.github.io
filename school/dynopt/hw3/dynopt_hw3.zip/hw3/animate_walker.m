function animate_walker(leg1_angles, leg2_angles, com)
% Joint angles will be 2xT, com will be 2xT also
leg1_angles = [linspace(-pi/4,pi/4,100)', linspace(pi/4,-pi/4,100)'];
leg2_angles = [zeros(100,1), zeros(100,1)];
com = [3*ones(100,1), 3*ones(100,1)];

T = size(com,1);

for i = 1:T
   plot_walker2d(leg1_angles(i,:), leg2_angles(i,:), com(i,:));
   pause(0.01);
end

end