function [F1, F2] = calculate_foot_forces(com, foot1, foot2, realness)
% Calculates foot forces (vectors), given foot positions


end