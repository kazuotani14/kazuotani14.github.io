clc; clear; close all;

%%%%% Define CIO problem %%%%%
global com_init com_goal dt T;
[feet_pos_forces, lb, ub] = setup_problem();

%%%%%% Solve problem %%%%%
global w_ci w_physics w_task;

global printout;
printout = 0;

n_phases = 1;

for phase = 1:n_phases
    switch phase
        case 1
            w_ci = 0.5;      %0
            w_physics = 0.1; %0
            w_task = 1;    %1
        case 2
            w_ci = 1;
            w_physics = 0.1;
            w_task = 1;
        case 3
            w_ci = 1;
            w_physics = 1;
            w_task = 1;
    end
    
    % Add zero-mean gaussian noise
%     feet_pos_forces = feet_pos_forces + randn(length(feet_pos_forces),1)*0.01;
    
    % Opt algorithms: 1 - SQP, 2 - Interior point (default), 3 - CMA-ES, 
    algorithm = 2;
    max_iter = 10;
    switch algorithm
        case 1  % SQP
            options = optimset('Display','iter','MaxIter',max_iter,'MaxFunEvals',100000,'Algorithm','sqp');
            [feet_pos_forces,fval,exitflag]=fmincon(@criterion,feet_pos_forces, [], [], [], [], lb, ub, @constraint, options);
        case 2  % Interior point
            options = optimset('Display','iter','MaxIter',max_iter,'MaxFunEvals',100000,'Algorithm','interior-point');
            [feet_pos_forces,fval,exitflag]=fmincon(@criterion,feet_pos_forces, [], [], [], [], lb, ub, @constraint, options);
        case 3 % CMA-ES
            n_vars = 8;
            sigma0 = ones(length(feet_pos_forces),1)*0.2;
            opts = cmaes;
            opts.MaxIter = 300; 
            [xmin, fmin, counteval, stopflag, out, bestever] = cmaes('criterion', feet_pos_forces, sigma0, opts);
            feet_pos_forces = xmin; fval = fmin; exitflag=1;
    end
    
end

%%%%% Animate solution %%%%%%
animate_solution(com_init, com_goal, dt, T, feet_pos_forces);