% Plot CoM
com = [2,2,2];
plot3(com(1), com(2), com(3),'.','MarkerSize',100,'Color','r');
axis([0,5,0,5,0,5]);
hold on;

% Define leg position by roll (about x axis) and pitch (about y axis)
leg_l = 2;
r1 = 0;
p1 = pi/4;
r2 = pi/4;
p2 = 0;

foot1 = [com(1)-leg_l*cos(r1)*sin(p1), com(2)+leg_l*sin(r1)*sin(p1), com(3)-leg_l*cos(p1)];
foot2 = [com(1)-leg_l*cos(r2)*sin(p2), com(2)+leg_l*sin(r2)*sin(p2), com(3)-leg_l*cos(p2)];

plot3([com(1), foot1(1)], [com(2), foot1(2)], [com(3),foot1(3)])
% plot3([com(1), 0], [com(2), 0], [com(3),0])

