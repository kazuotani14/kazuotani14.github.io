function [s0, lb, ub] = setup_problem()

global com_init com_goal m g dt T mu_static n_cphases;

com_init = [2,1];
com_goal = [9,1.5];
m = 5; %[kg]
dt = 0.1; %[s]
T = 200; % number of timesteps
mu_static = 50; %assume slip is almost impossible, for now
g = 9.81;
n_cphases = 10;

init_one = [0, (m*g)/2, 2, 0.5, 0, (m*g)/2, 5, 0.5]';
s0 = repmat(init_one, T, 1);

%        [Fy1, Fz1, y1, z1, Fy2, Fz2, y2, z2]
lb_one = [-10  eps eps eps  -10  eps eps eps]';
ub_one = [ 10   30  10   2   10   30  10   2]';

lb = repmat(lb_one, T, 1);
ub = repmat(ub_one, T, 1);

end