function [L1foot, L2foot] = plot_walker2d(leg1_angles, leg2_angles, com)
% Calculates joint positions based on joint angles
% Returns foot positions

% TEST
L1j1 = pi/4;
L1j2 = -pi/4;
L2j1 = -pi/4;
L2j2 = pi/4;
com = [1.75,1.75]; 

% % Read joint angles
% L1j1 = leg1_angles(1);
% L1j2 = leg1_angles(2);
% L2j1 = leg2_angles(1);
% L2j2 = leg2_angles(2);

% Plot CoM
plot(com(1), com(2), '.', 'MarkerSize', 100, 'Color', 'b');
axis([0,10, -0.2,3]);
hold on;

% Plot ground
plot([0,10],[0,0],'Color','k','LineWidth',2);

% Plot legs - joint angles defined wrt hanging down
link_l = 1;

L1k1 = [com(1)+link_l*sin(L1j1), com(2)-link_l*cos(L1j1)];
L1foot = [L1k1(1)+link_l*sin(L1j1+L1j2), L1k1(2)-link_l*cos(L1j1+L1j2)];
L2k1 = [com(1)+link_l*sin(L2j1), com(2)-link_l*cos(L2j1)];
L2foot = [L2k1(1)+link_l*sin(L2j1+L2j2), L2k1(2)-link_l*cos(L2j1+L2j2)];

plot([com(1), L1k1(1)], [com(2), L1k1(2)], 'Color', 'r', 'LineWidth', 5);
plot([L1k1(1), L1foot(1)], [L1k1(2), L1foot(2)], 'Color', 'r', 'LineWidth', 5);
plot([com(1), L2k1(1)], [com(2), L2k1(2)], 'Color', 'g', 'LineWidth', 5);
plot([L2k1(1), L2foot(1)], [L2k1(2), L2foot(2)], 'Color', 'g', 'LineWidth', 5);

% Plot feet
plot(L1foot(1),L1foot(2),'.','MarkerSize',20,'Color','r');
plot(L2foot(1),L2foot(2),'.','MarkerSize',20,'Color','g');

hold off

end