function animate_solution(com_init, com_goal, dt, T, feet_pos_forces)

    global m g printout;

    % Integrate foot positions and forces to find com positions
    foot1_positions = zeros(T,2);
    foot2_positions = zeros(T,2);
    com_positions   = zeros(T,2);
    F1 = zeros(T,2);
    F2 = zeros(T,2);
    
    com = com_init;
    for i = 1:T
       idx = 8*(i-1)+1;
       % [Fy1, Fz1, y1, z1, Fy2, Fz2, y2, z2]
       Fy1 = feet_pos_forces(idx);   Fz1 = feet_pos_forces(idx+1);
       Fy2 = feet_pos_forces(idx+4); Fz2 = feet_pos_forces(idx+5);
       F1(i,:) = [Fy1, Fz1];
       F2(i,:) = [Fy2, Fz2];
       
       y1  = feet_pos_forces(idx+2); z1  = feet_pos_forces(idx+3);
       y2  = feet_pos_forces(idx+6); z2  = feet_pos_forces(idx+7);
       foot1_positions(i,:) = [y1, z1];
       foot2_positions(i,:) = [y2, z2];

       % Euler integration of com position
       dy = (Fy1+Fy2) * dt; % Assume quasistatic, no velocities
       dz = ((Fz1+Fz2) - (m*g)) * dt;
       com(1) = com(1) + dy;
       com(2) = com(2) + dz;

       com_positions(i,:) = com;
    end

    % Animate!
%     disp('Hit enter to start animation');
%     figure
%     pause
    for i = 1:T
        plot_torso_and_feet(com_positions(i,:), foot1_positions(i,:), foot2_positions(i,:), com_goal);
        pause(0.01);
    end
    
    printout = 1;
    criterion(feet_pos_forces);
end

function plot_torso_and_feet(com, foot1, foot2, com_goal)    
    % Plot CoM
    plot(com(1), com(2), '.', 'MarkerSize', 100, 'Color', 'b');
    axis([0,10, -0.2,3]);
    hold on;
    
    % Plot goal CoM position
    plot(com_goal(1), com_goal(2), '.', 'MarkerSize', 100, 'Color', 'k');

    % Plot ground
    plot([0,10],[0,0],'Color','k','LineWidth',2);

    % Plot feet
    plot(foot1(1),foot1(2),'.','MarkerSize',30,'Color','r');
    plot(foot2(1),foot2(2),'.','MarkerSize',30,'Color','g');
    
    % Plot virtual legs
    plot([com(1) foot1(1)], [com(2) foot1(2)],'--','Color','r');
    plot([com(1) foot2(1)], [com(2) foot2(2)],'--','Color','g');

    % TODO plot force vectors
    
    hold off
end
