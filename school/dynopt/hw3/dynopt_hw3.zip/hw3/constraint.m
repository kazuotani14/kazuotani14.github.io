function [c_ineq, c_eq] = constraint(feet_pos_forces)
% optimizer will make sure c_ineq<=0, c_eq=0
s = feet_pos_forces;
global m g mu_static;

% [Fy1, Fz1, y1, z1, Fy2, Fz2, y2, z2]
N = length(s);
Fy_all = [s(1:8:N) s(5:8:N)];
Fz_all = [s(2:8:N) s(6:8:N)];
z_all  = [s(4:8:N) s(8:8:N)];
    
%%% Equality constraints %%%
% Sum of vertical foot forces must add up to gravity vector
Fz_sums = sum(Fz_all, 2);
diffs = Fz_sums - m*g;
c_gravity = sum(diffs(:)); 

% Foot positions must be positive
under_ground = z_all(z_all<-0.05);
c_ground = abs(sum(under_ground(:)));

c_eq = c_gravity + c_ground;

%%% Inequality constraints %%%
% z-component of contact forces must be positive
% Fz_negative = Fz_all(Fz_all>=0);
% c_pos_ground_forces = sum(abs(Fz_negative(:)));

% Contact force vectors must stay within friction cone
fric_calc = abs(Fy_all ./ Fz_all) - mu_static;
violating_f_cone = fric_calc(fric_calc > 0);
c_friction_cone = sum(abs(violating_f_cone(:)));

c_ineq = c_friction_cone;

% disp([c_eq, c_ineq]);
end