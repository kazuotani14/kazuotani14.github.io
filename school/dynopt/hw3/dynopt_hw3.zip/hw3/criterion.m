function score = criterion(feet_pos_forces) 
%%% optimization criterion

global com_init com_goal dt T m g;
global w_ci w_physics w_task;
global printout;
leg_length = 1; % TODO find better way to do this
cushion = 0.2; % discourage full extension - leads to singularity 

com = com_init; % center of mass position
L_ci = 0; % Realness of force
L_physics = 0; %Feasibility of foot position
L_task = 0; % Distance from goal com position

% Integrate foot forces at each timestep, while accumulating cost
for i = 1:T
   idx = 8*(i-1)+1;
   % [Fy1, Fz1, y1, z1, Fy2, Fz2, y2, z2]
   Fy1 = feet_pos_forces(idx);
   Fz1 = feet_pos_forces(idx+1);
   y1  = feet_pos_forces(idx+2);
   z1  = feet_pos_forces(idx+3);
   Fy2 = feet_pos_forces(idx+4);
   Fz2 = feet_pos_forces(idx+5);
   y2  = feet_pos_forces(idx+6);
   z2  = feet_pos_forces(idx+7);
%    disp([Fy1, Fz1, y1, z1, Fy2, Fz2, y2, z2])
      
   % Euler integration of com position
   dy = (Fy1+Fy2) * dt; % Assume quasistatic, no velocities
   dz = ((Fz1+Fz2)- (m*g)) * dt;
   com(1) = com(1) + dy;
   com(2) = com(2) + dz;
   
   % Calculate and add costs
   if com(2)<0
       l_ground = 10*abs(com(2));
   else
       l_ground = 0;
   end
   
   dist_com2feet = [norm(com-[y1,z1]) norm(com-[y2,z2])];
   dist_com2feet(dist_com2feet < (2*leg_length)-cushion) = 0;
   l_reachability = sum(dist_com2feet(:));
   
   % Cost for moment about center of mass. This would ideally be zero
   foot1_to_com = [y1-com(1) z1-com(2) 0];
   foot2_to_com = [y2-com(1) z2-com(2) 0];
   moment1 = cross(foot1_to_com, [Fy1, Fz1, 0]);
   moment2 = cross(foot2_to_com, [Fy2, Fz2, 0]);
   l_moment = abs(moment1(3)+moment2(3));
      
   %Foot sliding cost
   if i==1
       l_slide = 0;
   else
       idx_prev = 8*(i-2)+1;
       y1_prev = feet_pos_forces(idx_prev+2);
       y2_prev = feet_pos_forces(idx_prev+6);
       z1_prev = feet_pos_forces(idx_prev+3);
       z2_prev = feet_pos_forces(idx_prev+7);
       cost_slide = (1/(z1+0.1))^2*abs(y1-y1_prev) + (1/(z2+0.1))^2*abs(y2-y2_prev);
       cost_raise = abs(z1-z1_prev) + abs(z2-z2_prev);
       l_slide = cost_slide;
   end
   
%    l_reachability = 0;
%    l_moment = 0;
%    l_slide = 0;
%    l_ground = 0;
   
   l_physics = l_reachability + l_moment + l_slide + l_ground;
   l_ci = 50*((Fz1*z1^2) + (Fz2*z2^2));
   l_task  = norm(com_goal - com);

    if printout
        disp([l_reachability, l_moment, l_slide, l_ground]);
        disp([l_physics, l_ci, l_task]);
        disp('---');
    end
   
   L_ci = L_ci + l_ci;
   L_physics = L_physics + l_physics;
   L_task = L_task + l_task;
end

L_ci = w_ci*L_ci;
L_physics = w_physics*L_physics;
L_task = w_task*L_task;
score = L_ci + L_physics + L_task;

% disp([L_ci, L_physics, L_task]);
end
